<?php
/**
 * 
 * @author kblee
 *
 */
interface Callback{
	
	/**
	 * execute callback
	 */
	public function doCallback();
}
?>