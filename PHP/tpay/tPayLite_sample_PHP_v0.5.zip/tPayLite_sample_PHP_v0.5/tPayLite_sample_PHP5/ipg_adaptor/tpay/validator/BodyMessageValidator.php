<?php
/**
 * 
 * @author kblee
 *
 */
interface BodyMessageValidator{
	
	/**
	 * 
	 * @param $mdto
	 */
	public function validate($mdto);
	
}
?>