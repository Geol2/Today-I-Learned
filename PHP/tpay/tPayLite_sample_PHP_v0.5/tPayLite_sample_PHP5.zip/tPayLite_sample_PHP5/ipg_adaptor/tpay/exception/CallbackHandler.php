<?php
/**
 * 
 * @author kblee
 *
 */
interface CallbackHandler{
	/**
	 * 
	 * @param  $callbacks
	 */
	public function doHandle($callbacks);
}
?>