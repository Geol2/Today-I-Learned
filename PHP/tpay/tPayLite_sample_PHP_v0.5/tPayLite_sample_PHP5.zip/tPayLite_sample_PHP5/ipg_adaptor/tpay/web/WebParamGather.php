<?php
/**
 * 
 * @author kblee
 *
 */
interface WebParamGather{
	
	/**
	 * 
	 * @param $request
	 */
	public function gather($request);
}

?>